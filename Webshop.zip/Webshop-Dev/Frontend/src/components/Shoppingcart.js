import React from "react";

const Shoppingcart = () => {
    return (
    <h1>Shoppingcart</h1>
    )
        
    
}

export default Shoppingcart;