import React from "react";

const Customer = () => {
    return (
    <h1>Customer</h1>
    )
        
    
}

export default Customer;