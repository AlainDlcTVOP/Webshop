import React from "react";

const ProductDetials = () => {
    return (
    <h1>ProductDetials</h1>
    )
        
    
}

export default ProductDetials;