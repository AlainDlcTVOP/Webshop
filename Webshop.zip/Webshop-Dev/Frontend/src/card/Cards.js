import React from "react";

const Cards = () => {
    return (
        <h1>placeholder</h1>
    )
}

export default Cards;