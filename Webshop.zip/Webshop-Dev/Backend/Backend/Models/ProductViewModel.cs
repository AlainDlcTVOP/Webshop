﻿using SkiShop.Models;

namespace Backend.Models
{
    public class ProductViewModel
    {
        public Product Product { get; set; }
    }
}
