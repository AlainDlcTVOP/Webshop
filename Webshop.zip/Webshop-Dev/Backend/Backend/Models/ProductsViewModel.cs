﻿using SkiShop.Models;

namespace Backend.Models
{
    public class ProductsViewModel
    {
        public List<Product> Products { get; set; }
    }
}
